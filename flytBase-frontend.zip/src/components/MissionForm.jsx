import { useState, useEffect } from 'react'
import MapSelector from './MapSelector'
import { droneService } from '../services/droneService'
import './MissionForm.css'

/**
 * MissionForm Component
 * Form for creating a new mission
 */
const MissionForm = ({ onSubmit, loading }) => {
  const [formData, setFormData] = useState({
    missionName: '',
    areaName: '',
    altitude: 100,
    patternType: 'PERIMETER',
    latitude: null,
    longitude: null,
    droneId: ''
  })
  const [availableDrones, setAvailableDrones] = useState([])
  const [loadingDrones, setLoadingDrones] = useState(true)
  const [error, setError] = useState(null)

  /**
   * Fetch available drones on component mount
   */
  useEffect(() => {
    const fetchAvailableDrones = async () => {
      try {
        setLoadingDrones(true)
        const response = await droneService.getAvailable()
        setAvailableDrones(response.data || [])
      } catch (err) {
        console.error('Error fetching available drones:', err)
        setAvailableDrones([])
      } finally {
        setLoadingDrones(false)
      }
    }
    fetchAvailableDrones()
  }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: name === 'altitude' ? parseInt(value) || 0 : value
    }))
  }

  const handleLocationSelect = (lat, lng) => {
    setFormData(prev => ({
      ...prev,
      latitude: lat,
      longitude: lng
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)

    // Validation
    if (!formData.missionName.trim()) {
      setError('Mission name is required')
      return
    }

    if (!formData.areaName.trim()) {
      setError('Area name is required')
      return
    }

    if (formData.altitude < 0) {
      setError('Altitude must be a positive number')
      return
    }

    try {
      await onSubmit(formData)
      // Reset form on success
      setFormData({
        missionName: '',
        areaName: '',
        altitude: 100,
        patternType: 'PERIMETER',
        latitude: null,
        longitude: null,
        droneId: ''
      })
      
      // Refresh available drones list
      const response = await droneService.getAvailable()
      setAvailableDrones(response.data || [])
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="mission-form-container">
      <h2>Create New Mission</h2>
      <form className="mission-form" onSubmit={handleSubmit}>
        {error && (
          <div className="error-message">
            {error}
          </div>
        )}

          <div className="form-group">
            <label htmlFor="missionName">Mission Name *</label>
            <input
              type="text"
              id="missionName"
              name="missionName"
              value={formData.missionName}
              onChange={handleChange}
              required
              placeholder="Enter mission name"
            />
          </div>

          <div className="form-group">
            <label htmlFor="areaName">Area Name *</label>
            <input
              type="text"
              id="areaName"
              name="areaName"
              value={formData.areaName}
              onChange={handleChange}
              required
              placeholder="Enter area name"
            />
          </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="altitude">Altitude (meters)</label>
            <input
              type="number"
              id="altitude"
              name="altitude"
              value={formData.altitude}
              onChange={handleChange}
              min="0"
              placeholder="100"
            />
          </div>

          <div className="form-group">
            <label htmlFor="patternType">Pattern Type</label>
            <select
              id="patternType"
              name="patternType"
              value={formData.patternType}
              onChange={handleChange}
            >
              <option value="PERIMETER">Perimeter</option>
              <option value="CROSSHATCH">Crosshatch</option>
            </select>
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="droneId">Assign Drone (Optional)</label>
          <select
            id="droneId"
            name="droneId"
            value={formData.droneId}
            onChange={handleChange}
            disabled={loadingDrones}
          >
            <option value="">-- Select Available Drone --</option>
            {availableDrones.map(drone => (
              <option key={drone.id} value={drone.id}>
                {drone.droneName} (Battery: {drone.batteryLevel}%)
              </option>
            ))}
          </select>
          {loadingDrones && (
            <small className="form-hint">Loading available drones...</small>
          )}
          {!loadingDrones && availableDrones.length === 0 && (
            <small className="form-hint">No available drones. Create a drone first.</small>
          )}
        </div>

        <div className="form-group map-selector-group">
          <MapSelector
            onLocationSelect={handleLocationSelect}
            selectedLat={formData.latitude}
            selectedLng={formData.longitude}
          />
        </div>

        <div className="form-actions">
          <button
            type="submit"
            className="btn btn-primary"
            disabled={loading}
          >
            {loading ? 'Creating...' : 'Create Mission'}
          </button>
        </div>
      </form>
    </div>
  )
}

export default MissionForm
