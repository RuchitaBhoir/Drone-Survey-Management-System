import { useEffect, useState } from 'react'
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import './MapSelector.css'

// Fix for default marker icon in React-Leaflet
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
})

/**
 * MapClickHandler component
 * Handles map click events to set marker position
 */
function MapClickHandler({ onLocationSelect }) {
  useMapEvents({
    click: (e) => {
      const { lat, lng } = e.latlng
      onLocationSelect(lat, lng)
    },
  })
  return null
}

/**
 * ChangeMapView component
 * Updates map center when position changes
 */
function ChangeMapView({ center }) {
  const map = useMap()
  useEffect(() => {
    if (center) {
      map.setView(center, map.getZoom())
    }
  }, [center, map])
  return null
}

/**
 * MapSelector Component
 * Displays a map and allows user to click to select a location
 */
const MapSelector = ({ onLocationSelect, initialLat = 28.6139, initialLng = 77.2090, selectedLat, selectedLng }) => {
  const [position, setPosition] = useState(
    selectedLat && selectedLng 
      ? [selectedLat, selectedLng] 
      : [initialLat, initialLng]
  )

  useEffect(() => {
    if (selectedLat && selectedLng) {
      setPosition([selectedLat, selectedLng])
    }
  }, [selectedLat, selectedLng])

  const handleMapClick = (lat, lng) => {
    setPosition([lat, lng])
    onLocationSelect(lat, lng)
  }

  return (
    <div className="map-selector-container">
      <div className="map-selector-header">
        <h3>Select Survey Area Center</h3>
        <p className="map-instructions">Click on the map to set the mission location</p>
      </div>
      <div className="map-wrapper">
        <MapContainer
          center={position}
          zoom={13}
          style={{ height: '400px', width: '100%' }}
          scrollWheelZoom={true}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <ChangeMapView center={position} />
          <MapClickHandler onLocationSelect={handleMapClick} />
          {position && (
            <Marker position={position} />
          )}
        </MapContainer>
      </div>
      {position && (
        <div className="map-coordinates">
          <span className="coordinate-label">Latitude:</span>
          <span className="coordinate-value">{position[0].toFixed(6)}</span>
          <span className="coordinate-label">Longitude:</span>
          <span className="coordinate-value">{position[1].toFixed(6)}</span>
        </div>
      )}
    </div>
  )
}

export default MapSelector
