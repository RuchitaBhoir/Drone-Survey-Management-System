import { Link } from 'react-router-dom'
import './MissionCard.css'

/**
 * MissionCard Component
 * Displays a single mission card
 */
const MissionCard = ({ mission }) => {
  const getStatusBadgeClass = (status) => {
    const classes = {
      PLANNED: 'badge-planned',
      IN_PROGRESS: 'badge-in-progress',
      PAUSED: 'badge-paused',
      COMPLETED: 'badge-completed',
      ABORTED: 'badge-aborted'
    }
    return classes[status] || 'badge-planned'
  }

  const getPatternIcon = (pattern) => {
    return pattern === 'PERIMETER' ? '📐' : '🔲'
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A'
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <div className="mission-card">
      <div className="mission-card-header">
        <h3 className="mission-name">{mission.missionName}</h3>
        <span className={`badge ${getStatusBadgeClass(mission.status)}`}>
          {mission.status.replace('_', ' ')}
        </span>
      </div>

      <div className="mission-card-body">
        <div className="mission-info">
          <div className="info-item">
            <span className="info-label">Area:</span>
            <span className="info-value">{mission.areaName}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Altitude:</span>
            <span className="info-value">{mission.altitude}m</span>
          </div>
          <div className="info-item">
            <span className="info-label">Pattern:</span>
            <span className="info-value">
              {getPatternIcon(mission.patternType)} {mission.patternType}
            </span>
          </div>
          {mission.droneId && (
            <div className="info-item">
              <span className="info-label">Assigned Drone:</span>
              <span className="info-value">Drone ID: {mission.droneId}</span>
            </div>
          )}
          {mission.status === 'IN_PROGRESS' && (
            <div className="info-item">
              <span className="info-label">Progress:</span>
              <div className="progress-container">
                <div className="progress-bar">
                  <div 
                    className="progress-fill" 
                    style={{ width: `${mission.progress}%` }}
                  ></div>
                </div>
                <span className="progress-text">{mission.progress}%</span>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="mission-card-footer">
        <span className="mission-date">
          Created: {formatDate(mission.createdAt)}
        </span>
        <div className="mission-actions">
          {mission.status === 'PLANNED' && (
            <button
              onClick={() => mission.onStart && mission.onStart(mission.id)}
              className="btn-start"
              disabled={mission.starting}
            >
              {mission.starting ? 'Starting...' : '▶ Start Mission'}
            </button>
          )}
          {(mission.status === 'IN_PROGRESS' || mission.status === 'PAUSED') && (
            <Link 
              to={`/missions/${mission.id}/monitor`}
              className="btn-monitor"
            >
              Monitor →
            </Link>
          )}
        </div>
      </div>
    </div>
  )
}

export default MissionCard
