import { Link, useLocation } from 'react-router-dom'
import './Layout.css'

const Layout = ({ children }) => {
  const location = useLocation()

  const isActive = (path) => {
    return location.pathname === path ? 'active' : ''
  }

  return (
    <div className="layout">
      <header className="header">
        <div className="container">
          <h1 className="logo">Drone Survey Management</h1>
          <nav className="nav">
            <Link to="/" className={`nav-link ${isActive('/')}`}>
              Dashboard
            </Link>
            <Link to="/surveys" className={`nav-link ${isActive('/surveys')}`}>
              Surveys
            </Link>
            <Link to="/fleet" className={`nav-link ${isActive('/fleet')}`}>
              Fleet
            </Link>
            <Link to="/missions" className={`nav-link ${isActive('/missions')}`}>
              Missions
            </Link>
          </nav>
        </div>
      </header>
      
      <main className="main-content">
        <div className="container">
          {children}
        </div>
      </main>
      
      <footer className="footer">
        <div className="container">
          <p>&copy; 2024 Drone Survey Management System</p>
        </div>
      </footer>
    </div>
  )
}

export default Layout
