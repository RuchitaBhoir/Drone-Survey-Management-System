import './DroneRow.css'

/**
 * DroneRow Component
 * Displays a single drone row in the table
 */
const DroneRow = ({ drone, onStatusUpdate }) => {
  const getStatusBadgeClass = (status) => {
    const classes = {
      AVAILABLE: 'badge-available',
      IN_MISSION: 'badge-in-mission'
    }
    return classes[status] || 'badge-available'
  }

  const getBatteryColor = (level) => {
    if (level >= 80) return 'battery-high'
    if (level >= 50) return 'battery-medium'
    if (level >= 20) return 'battery-low'
    return 'battery-critical'
  }

  const handleStatusToggle = () => {
    const newStatus = drone.status === 'AVAILABLE' ? 'IN_MISSION' : 'AVAILABLE'
    onStatusUpdate(drone.id, { status: newStatus })
  }

  return (
    <tr className="drone-row">
      <td className="drone-name">{drone.droneName}</td>
      <td>
        <span className={`badge ${getStatusBadgeClass(drone.status)}`}>
          {drone.status.replace('_', ' ')}
        </span>
      </td>
      <td>
        <div className="battery-container">
          <div className={`battery-level ${getBatteryColor(drone.batteryLevel)}`}>
            <div 
              className="battery-fill" 
              style={{ width: `${drone.batteryLevel}%` }}
            ></div>
            <span className="battery-text">{drone.batteryLevel}%</span>
          </div>
        </div>
      </td>
      <td>
        <button
          onClick={handleStatusToggle}
          className={`btn btn-status ${drone.status === 'AVAILABLE' ? 'btn-available' : 'btn-in-mission'}`}
          title={drone.status === 'AVAILABLE' 
            ? 'Manually set to IN_MISSION (usually set automatically when assigned to mission)' 
            : 'Manually set to AVAILABLE (usually set automatically when mission completes)'}
        >
          {drone.status === 'AVAILABLE' ? 'Set In Mission' : 'Set Available'}
        </button>
      </td>
    </tr>
  )
}

export default DroneRow
