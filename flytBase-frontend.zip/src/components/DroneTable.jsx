import DroneRow from './DroneRow'
import './DroneTable.css'

/**
 * DroneTable Component
 * Displays a table of drones
 */
const DroneTable = ({ drones, onStatusUpdate, loading }) => {
  if (loading) {
    return (
      <div className="drone-table-loading">
        <p>Loading drones...</p>
      </div>
    )
  }

  if (drones.length === 0) {
    return (
      <div className="drone-table-empty">
        <p>No drones found in the fleet.</p>
      </div>
    )
  }

  return (
    <div className="drone-table-container">
      <table className="drone-table">
        <thead>
          <tr>
            <th>Drone Name</th>
            <th>Status</th>
            <th>Battery Level</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {drones.map(drone => (
            <DroneRow
              key={drone.id}
              drone={drone}
              onStatusUpdate={onStatusUpdate}
            />
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default DroneTable
