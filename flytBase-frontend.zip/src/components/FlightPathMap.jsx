import { useEffect, useState, useRef } from 'react'
import { MapContainer, TileLayer, Polyline, Marker, useMap } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import './FlightPathMap.css'

// Fix for default marker icon in React-Leaflet
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
})

// Custom drone icon
const createDroneIcon = () => {
  return L.divIcon({
    className: 'drone-marker',
    html: '<div class="drone-icon">🚁</div>',
    iconSize: [32, 32],
    iconAnchor: [16, 16]
  })
}

/**
 * MapViewUpdater component
 * Updates map view when center changes
 */
function MapViewUpdater({ center, bounds }) {
  const map = useMap()
  
  useEffect(() => {
    if (bounds) {
      map.fitBounds(bounds, { padding: [50, 50] })
    } else if (center) {
      map.setView(center, 15)
    }
  }, [center, bounds, map])
  
  return null
}

/**
 * FlightPathMap Component
 * Displays flight path and animated drone marker
 */
const FlightPathMap = ({ mission }) => {
  const [flightPath, setFlightPath] = useState([])
  const [dronePosition, setDronePosition] = useState(null)
  const [mapCenter, setMapCenter] = useState(null)
  const [mapBounds, setMapBounds] = useState(null)
  const animationRef = useRef(null)

  /**
   * Generate flight path based on pattern type
   */
  const generateFlightPath = (centerLat, centerLng, patternType) => {
    if (!centerLat || !centerLng) {
      // Default to Delhi if no center provided
      return generatePath(28.6139, 77.2090, patternType)
    }
    return generatePath(centerLat, centerLng, patternType)
  }

  /**
   * Generate path coordinates based on pattern
   */
  const generatePath = (centerLat, centerLng, patternType) => {
    const path = []
    const radius = 0.01 // ~1km radius in degrees (adjustable)
    const points = 20 // Number of points in the path

    if (patternType === 'PERIMETER') {
      // Create a rectangular perimeter path
      const halfRadius = radius * 0.7
      const corners = [
        [centerLat + halfRadius, centerLng - halfRadius], // Top-left
        [centerLat + halfRadius, centerLng + halfRadius], // Top-right
        [centerLat - halfRadius, centerLng + halfRadius], // Bottom-right
        [centerLat - halfRadius, centerLng - halfRadius], // Bottom-left
        [centerLat + halfRadius, centerLng - halfRadius] // Close the loop
      ]
      
      // Interpolate between corners for smoother path
      for (let i = 0; i < corners.length - 1; i++) {
        const start = corners[i]
        const end = corners[i + 1]
        const segments = 5
        for (let j = 0; j <= segments; j++) {
          const ratio = j / segments
          path.push([
            start[0] + (end[0] - start[0]) * ratio,
            start[1] + (end[1] - start[1]) * ratio
          ])
        }
      }
    } else if (patternType === 'CROSSHATCH') {
      // Create a crosshatch pattern (grid-like)
      const halfRadius = radius * 0.7
      const gridLines = 4
      
      // Horizontal lines
      for (let i = 0; i <= gridLines; i++) {
        const lat = centerLat + halfRadius - (2 * halfRadius * i / gridLines)
        path.push([lat, centerLng - halfRadius])
        path.push([lat, centerLng + halfRadius])
      }
      
      // Vertical lines
      for (let i = 0; i <= gridLines; i++) {
        const lng = centerLng - halfRadius + (2 * halfRadius * i / gridLines)
        path.push([centerLat + halfRadius, lng])
        path.push([centerLat - halfRadius, lng])
      }
    } else {
      // Default: simple circular path
      for (let i = 0; i <= points; i++) {
        const angle = (i / points) * 2 * Math.PI
        path.push([
          centerLat + radius * Math.cos(angle),
          centerLng + radius * Math.sin(angle)
        ])
      }
    }

    return path
  }

  /**
   * Calculate drone position based on progress
   */
  const calculateDronePosition = (path, progress) => {
    if (!path || path.length === 0 || progress <= 0) {
      return path && path.length > 0 ? path[0] : null
    }

    if (progress >= 100) {
      return path[path.length - 1]
    }

    const totalDistance = path.length - 1
    const targetIndex = Math.floor((progress / 100) * totalDistance)
    const nextIndex = Math.min(targetIndex + 1, path.length - 1)
    
    // Interpolate between current and next point for smooth movement
    const currentPoint = path[targetIndex]
    const nextPoint = path[nextIndex]
    const segmentProgress = ((progress / 100) * totalDistance) % 1

    return [
      currentPoint[0] + (nextPoint[0] - currentPoint[0]) * segmentProgress,
      currentPoint[1] + (nextPoint[1] - currentPoint[1]) * segmentProgress
    ]
  }

  /**
   * Calculate map bounds from path
   */
  const calculateBounds = (path) => {
    if (!path || path.length === 0) return null
    
    const lats = path.map(p => p[0])
    const lngs = path.map(p => p[1])
    
    return [
      [Math.min(...lats), Math.min(...lngs)],
      [Math.max(...lats), Math.max(...lngs)]
    ]
  }

  /**
   * Update flight path and drone position when mission changes
   */
  useEffect(() => {
    if (!mission) return

    const centerLat = mission.centerLat || mission.latitude
    const centerLng = mission.centerLng || mission.longitude
    
    if (!centerLat || !centerLng) {
      // Use default center if no coordinates
      const defaultPath = generateFlightPath(28.6139, 77.2090, mission.patternType || 'PERIMETER')
      setFlightPath(defaultPath)
      setMapCenter([28.6139, 77.2090])
      setMapBounds(calculateBounds(defaultPath))
      return
    }

    const path = generateFlightPath(centerLat, centerLng, mission.patternType || 'PERIMETER')
    setFlightPath(path)
    setMapCenter([centerLat, centerLng])
    setMapBounds(calculateBounds(path))

    // Calculate initial drone position
    const dronePos = calculateDronePosition(path, mission.progress || 0)
    setDronePosition(dronePos)
  }, [mission?.centerLat, mission?.centerLng, mission?.latitude, mission?.longitude, mission?.patternType])

  /**
   * Update drone position when progress changes
   */
  useEffect(() => {
    if (!mission || !flightPath || flightPath.length === 0) return

    const progress = mission.progress || 0
    const newPosition = calculateDronePosition(flightPath, progress)
    
    // Smooth animation
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
    }

    const animate = () => {
      setDronePosition(newPosition)
    }
    
    animationRef.current = requestAnimationFrame(animate)
  }, [mission?.progress, flightPath])

  if (!mission) {
    return (
      <div className="flight-path-map-container">
        <div className="map-placeholder">
          <p>No mission data available</p>
        </div>
      </div>
    )
  }

  const centerLat = mission.centerLat || mission.latitude
  const centerLng = mission.centerLng || mission.longitude
  const defaultCenter = centerLat && centerLng ? [centerLat, centerLng] : [28.6139, 77.2090]

  return (
    <div className="flight-path-map-container">
      <div className="map-header">
        <h3>Flight Path Visualization</h3>
        <span className="map-status">
          {mission.status === 'IN_PROGRESS' ? '🟢 Active' : 
           mission.status === 'PAUSED' ? '⏸ Paused' : 
           mission.status === 'COMPLETED' ? '✅ Completed' : 
           mission.status === 'ABORTED' ? '⛔ Aborted' : '📋 Planned'}
        </span>
      </div>
      <div className="map-wrapper">
        <MapContainer
          center={defaultCenter}
          zoom={14}
          style={{ height: '500px', width: '100%' }}
          scrollWheelZoom={true}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapViewUpdater center={mapCenter} bounds={mapBounds} />
          
          {/* Flight path polyline */}
          {flightPath.length > 0 && (
            <Polyline
              positions={flightPath}
              color="#3498db"
              weight={3}
              opacity={0.7}
            />
          )}
          
          {/* Center marker */}
          {centerLat && centerLng && (
            <Marker
              position={[centerLat, centerLng]}
              icon={L.divIcon({
                className: 'center-marker',
                html: '<div class="center-icon">📍</div>',
                iconSize: [24, 24],
                iconAnchor: [12, 12]
              })}
            />
          )}
          
          {/* Animated drone marker */}
          {dronePosition && (
            <Marker
              position={dronePosition}
              icon={createDroneIcon()}
            />
          )}
        </MapContainer>
      </div>
      <div className="map-info">
        <div className="info-item">
          <span className="info-label">Pattern:</span>
          <span className="info-value">{mission.patternType || 'PERIMETER'}</span>
        </div>
        <div className="info-item">
          <span className="info-label">Progress:</span>
          <span className="info-value">{mission.progress || 0}%</span>
        </div>
        {dronePosition && (
          <div className="info-item">
            <span className="info-label">Drone Position:</span>
            <span className="info-value">
              {dronePosition[0].toFixed(6)}, {dronePosition[1].toFixed(6)}
            </span>
          </div>
        )}
      </div>
    </div>
  )
}

export default FlightPathMap
