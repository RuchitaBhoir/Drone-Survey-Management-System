import MissionCard from './MissionCard'
import './MissionList.css'

/**
 * MissionList Component
 * Displays a list of missions
 */
const MissionList = ({ missions, loading }) => {
  if (loading) {
    return (
      <div className="mission-list-loading">
        <p>Loading missions...</p>
      </div>
    )
  }

  if (missions.length === 0) {
    return (
      <div className="mission-list-empty">
        <p>No missions found. Create your first mission!</p>
      </div>
    )
  }

  return (
    <div className="mission-list">
      <h2>Missions ({missions.length})</h2>
      <div className="mission-grid">
        {missions.map(mission => (
          <MissionCard key={mission.id} mission={mission} />
        ))}
      </div>
    </div>
  )
}

export default MissionList
