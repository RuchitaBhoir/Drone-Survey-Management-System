import { useEffect, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { surveyAPI } from '../services/api'
import './SurveyDetail.css'

const SurveyDetail = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [survey, setSurvey] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchSurvey()
  }, [id])

  const fetchSurvey = async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await surveyAPI.getById(id)
      setSurvey(response.data)
    } catch (err) {
      setError(err.message)
      console.error('Error fetching survey:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this survey?')) {
      return
    }

    try {
      await surveyAPI.delete(id)
      navigate('/surveys')
    } catch (err) {
      alert('Error deleting survey: ' + err.message)
    }
  }

  const getStatusBadgeClass = (status) => {
    const classes = {
      pending: 'badge-pending',
      in_progress: 'badge-in-progress',
      completed: 'badge-completed',
      cancelled: 'badge-cancelled'
    }
    return classes[status] || 'badge-pending'
  }

  if (loading) {
    return <div className="loading">Loading survey details...</div>
  }

  if (error) {
    return (
      <div className="error-container">
        <div className="error">Error: {error}</div>
        <Link to="/surveys" className="btn btn-secondary">
          Back to Surveys
        </Link>
      </div>
    )
  }

  if (!survey) {
    return (
      <div className="error-container">
        <div className="error">Survey not found</div>
        <Link to="/surveys" className="btn btn-secondary">
          Back to Surveys
        </Link>
      </div>
    )
  }

  return (
    <div className="survey-detail">
      <div className="detail-header">
        <Link to="/surveys" className="back-link">← Back to Surveys</Link>
        <div className="header-actions">
          <button onClick={handleDelete} className="btn btn-danger">
            Delete Survey
          </button>
        </div>
      </div>

      <div className="detail-card">
        <div className="detail-header-section">
          <h1>{survey.name}</h1>
          <span className={`badge ${getStatusBadgeClass(survey.status)}`}>
            {survey.status.replace('_', ' ')}
          </span>
        </div>

        <div className="detail-content">
          <div className="detail-section">
            <h3>Description</h3>
            <p>{survey.description || 'No description provided'}</p>
          </div>

          <div className="detail-section">
            <h3>Location</h3>
            <p>{survey.location}</p>
          </div>

          {survey.latitude && survey.longitude && (
            <div className="detail-section">
              <h3>Coordinates</h3>
              <p>
                Latitude: {survey.latitude}, Longitude: {survey.longitude}
              </p>
            </div>
          )}

          <div className="detail-meta">
            <div className="meta-item">
              <strong>Created:</strong>{' '}
              {new Date(survey.createdAt).toLocaleString()}
            </div>
            <div className="meta-item">
              <strong>Last Updated:</strong>{' '}
              {new Date(survey.updatedAt).toLocaleString()}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SurveyDetail
