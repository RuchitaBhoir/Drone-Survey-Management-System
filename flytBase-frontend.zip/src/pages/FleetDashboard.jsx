import { useEffect, useState } from 'react'
import { droneService } from '../services/droneService'
import DroneTable from '../components/DroneTable'
import './FleetDashboard.css'

/**
 * FleetDashboard Page
 * Displays and manages the drone fleet
 */
const FleetDashboard = () => {
  const [drones, setDrones] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [updating, setUpdating] = useState(null)

  useEffect(() => {
    fetchDrones()
  }, [])

  /**
   * Fetch all drones from the backend
   */
  const fetchDrones = async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await droneService.getAll()
      setDrones(response.data || [])
    } catch (err) {
      setError(err.message)
      console.error('Error fetching drones:', err)
    } finally {
      setLoading(false)
    }
  }

  /**
   * Update drone status
   */
  const handleStatusUpdate = async (id, statusData) => {
    try {
      setUpdating(id)
      await droneService.updateStatus(id, statusData)
      
      // Update local state
      setDrones(drones.map(drone => 
        drone.id === id 
          ? { ...drone, status: statusData.status }
          : drone
      ))
    } catch (err) {
      alert('Error updating drone status: ' + err.message)
      console.error('Error updating drone status:', err)
    } finally {
      setUpdating(null)
    }
  }

  /**
   * Calculate fleet statistics
   */
  const stats = {
    total: drones.length,
    available: drones.filter(d => d.status === 'AVAILABLE').length,
    inMission: drones.filter(d => d.status === 'IN_MISSION').length,
    avgBattery: drones.length > 0
      ? Math.round(drones.reduce((sum, d) => sum + d.batteryLevel, 0) / drones.length)
      : 0
  }

  if (error && drones.length === 0) {
    return (
      <div className="fleet-dashboard">
        <div className="page-header">
          <h1>Drone Fleet Dashboard</h1>
        </div>
        <div className="error">
          <p>Error: {error}</p>
          <button onClick={fetchDrones} className="btn btn-primary">
            Retry
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="fleet-dashboard">
      <div className="page-header">
        <h1>Drone Fleet Dashboard</h1>
        <button 
          onClick={fetchDrones} 
          className="btn btn-secondary"
          disabled={loading}
        >
          {loading ? 'Refreshing...' : 'Refresh'}
        </button>
      </div>

      {/* Info Note */}
      <div className="info-note">
        <p>
          <strong>Note:</strong> Drone status is automatically managed through missions. 
          When a drone is assigned to a mission, it becomes "IN_MISSION". 
          When the mission completes or is aborted, it automatically becomes "AVAILABLE". 
          Manual status toggle is available for special cases (maintenance, manual returns, etc.).
        </p>
      </div>

      {/* Statistics Cards */}
      <div className="fleet-stats">
        <div className="stat-card">
          <h3>Total Drones</h3>
          <p className="stat-value">{stats.total}</p>
        </div>
        <div className="stat-card stat-available">
          <h3>Available</h3>
          <p className="stat-value">{stats.available}</p>
        </div>
        <div className="stat-card stat-in-mission">
          <h3>In Mission</h3>
          <p className="stat-value">{stats.inMission}</p>
        </div>
        <div className="stat-card stat-battery">
          <h3>Avg Battery</h3>
          <p className="stat-value">{stats.avgBattery}%</p>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="error-message">
          <p>Warning: {error}</p>
        </div>
      )}

      {/* Drone Table */}
      <DroneTable
        drones={drones}
        onStatusUpdate={handleStatusUpdate}
        loading={loading}
      />
    </div>
  )
}

export default FleetDashboard
