import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { surveyAPI } from '../services/api'
import './Dashboard.css'

const Dashboard = () => {
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    inProgress: 0,
    completed: 0
  })
  const [recentSurveys, setRecentSurveys] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      const response = await surveyAPI.getAll()
      const surveys = response.data || []

      // Calculate statistics
      const stats = {
        total: surveys.length,
        pending: surveys.filter(s => s.status === 'pending').length,
        inProgress: surveys.filter(s => s.status === 'in_progress').length,
        completed: surveys.filter(s => s.status === 'completed').length
      }

      setStats(stats)
      setRecentSurveys(surveys.slice(0, 5))
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadgeClass = (status) => {
    const classes = {
      pending: 'badge-pending',
      in_progress: 'badge-in-progress',
      completed: 'badge-completed',
      cancelled: 'badge-cancelled'
    }
    return classes[status] || 'badge-pending'
  }

  if (loading) {
    return <div className="loading">Loading dashboard...</div>
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Dashboard</h1>
        <Link to="/surveys/new" className="btn btn-primary">
          Create New Survey
        </Link>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <h3>Total Surveys</h3>
          <p className="stat-value">{stats.total}</p>
        </div>
        <div className="stat-card">
          <h3>Pending</h3>
          <p className="stat-value">{stats.pending}</p>
        </div>
        <div className="stat-card">
          <h3>In Progress</h3>
          <p className="stat-value">{stats.inProgress}</p>
        </div>
        <div className="stat-card">
          <h3>Completed</h3>
          <p className="stat-value">{stats.completed}</p>
        </div>
      </div>

      <div className="recent-surveys">
        <h2>Recent Surveys</h2>
        {recentSurveys.length === 0 ? (
          <p className="empty-state">No surveys found. Create your first survey!</p>
        ) : (
          <div className="surveys-list">
            {recentSurveys.map(survey => (
              <Link
                key={survey.id}
                to={`/surveys/${survey.id}`}
                className="survey-card"
              >
                <div className="survey-card-header">
                  <h3>{survey.name}</h3>
                  <span className={`badge ${getStatusBadgeClass(survey.status)}`}>
                    {survey.status.replace('_', ' ')}
                  </span>
                </div>
                <p className="survey-location">{survey.location}</p>
                <p className="survey-description">{survey.description}</p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default Dashboard
