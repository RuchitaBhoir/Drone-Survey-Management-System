import { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { missionService } from '../services/missionService'
import FlightPathMap from '../components/FlightPathMap'
import './MissionMonitor.css'

/**
 * MissionMonitor Page
 * Real-time mission monitoring with progress updates
 */
const MissionMonitor = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [mission, setMission] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [actionLoading, setActionLoading] = useState(null)

  /**
   * Fetch mission monitoring data
   */
  const fetchMissionData = useCallback(async () => {
    if (!id) return
    
    try {
      const response = await missionService.monitor(id)
      setMission(response.data)
      setError(null)
    } catch (err) {
      setError(err.message)
      console.error('Error fetching mission data:', err)
    } finally {
      setLoading(false)
    }
  }, [id])

  /**
   * Set up polling every 5 seconds
   */
  useEffect(() => {
    if (!id) return

    // Initial fetch
    fetchMissionData()

    // Set up polling interval
    const interval = setInterval(() => {
      fetchMissionData()
    }, 5000) // Poll every 5 seconds

    // Cleanup interval on unmount
    return () => clearInterval(interval)
  }, [id, fetchMissionData])

  /**
   * Handle mission control action (pause, resume, or abort)
   */
  const handleControlAction = async (action) => {
    // Confirmation for abort action
    if (action === 'abort') {
      if (!window.confirm('Are you sure you want to abort this mission?')) {
        return
      }
    }

    try {
      setActionLoading(action)
      const response = await missionService.control(id, action)
      setMission(response.data)
    } catch (err) {
      const actionName = action.charAt(0).toUpperCase() + action.slice(1)
      alert(`Error ${action}ing mission: ${err.message}`)
      console.error(`Error ${action}ing mission:`, err)
    } finally {
      setActionLoading(null)
    }
  }

  /**
   * Handle pause mission
   */
  const handlePause = () => handleControlAction('pause')

  /**
   * Handle resume mission
   */
  const handleResume = () => handleControlAction('resume')

  /**
   * Handle abort mission
   */
  const handleAbort = () => handleControlAction('abort')

  /**
   * Get status badge class
   */
  const getStatusBadgeClass = (status) => {
    const classes = {
      PLANNED: 'badge-planned',
      IN_PROGRESS: 'badge-in-progress',
      PAUSED: 'badge-paused',
      COMPLETED: 'badge-completed',
      ABORTED: 'badge-aborted'
    }
    return classes[status] || 'badge-planned'
  }

  /**
   * Format time remaining
   */
  const formatTimeRemaining = (seconds) => {
    if (!seconds || seconds <= 0) return '0s'
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    if (mins > 0) {
      return `${mins}m ${secs}s`
    }
    return `${secs}s`
  }

  /**
   * Format date
   */
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A'
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    })
  }

  if (loading && !mission) {
    return (
      <div className="mission-monitor">
        <div className="loading-container">
          <p>Loading mission data...</p>
        </div>
      </div>
    )
  }

  if (error && !mission) {
    return (
      <div className="mission-monitor">
        <div className="error-container">
          <p>Error: {error}</p>
          <button onClick={fetchMissionData} className="mission-monitor-btn btn-primary">
            Retry
          </button>
          <button onClick={() => navigate('/missions')} className="mission-monitor-btn btn-secondary">
            Back to Missions
          </button>
        </div>
      </div>
    )
  }

  if (!mission) {
    return (
      <div className="mission-monitor">
        <div className="error-container">
          <p>Mission not found</p>
          <button onClick={() => navigate('/missions')} className="btn btn-primary">
            Back to Missions
          </button>
        </div>
      </div>
    )
  }

  const canPause = mission.status === 'IN_PROGRESS'
  const canResume = mission.status === 'PAUSED'
  const canAbort = mission.status !== 'COMPLETED' && mission.status !== 'ABORTED'

  return (
    <div className="mission-monitor">
      <div className="page-header">
        <div>
          <button 
            onClick={() => navigate('/missions')} 
            className="btn btn-back"
          >
            ← Back to Missions
          </button>
          <h1>Mission Monitor</h1>
        </div>
        <div className="polling-indicator">
          <span className="polling-dot"></span>
          <span>Live Updates</span>
        </div>
      </div>

      <div className="mission-monitor-content">
        {/* Mission Info Card */}
        <div className="mission-info-card">
          <div className="mission-header">
            <h2>{mission.missionName}</h2>
            <span className={`badge ${getStatusBadgeClass(mission.status)}`}>
              {mission.status.replace('_', ' ')}
            </span>
          </div>

          <div className="mission-details">
            <div className="detail-item">
              <span className="detail-label">Area:</span>
              <span className="detail-value">{mission.areaName}</span>
            </div>
            <div className="detail-item">
              <span className="detail-label">Altitude:</span>
              <span className="detail-value">{mission.altitude}m</span>
            </div>
            <div className="detail-item">
              <span className="detail-label">Pattern:</span>
              <span className="detail-value">{mission.patternType}</span>
            </div>
            {mission.estimatedTimeRemainingSeconds && (
              <div className="detail-item">
                <span className="detail-label">Time Remaining:</span>
                <span className="detail-value time-remaining">
                  {formatTimeRemaining(mission.estimatedTimeRemainingSeconds)}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Flight Path Map */}
        <FlightPathMap mission={mission} />

        {/* Progress Card */}
        <div className="progress-card">
          <div className="progress-header">
            <h3>Mission Progress</h3>
            <span className="progress-percentage">{mission.progress}%</span>
          </div>
          <div className="progress-bar-container">
            <div className="progress-bar">
              <div 
                className="progress-fill"
                style={{ width: `${mission.progress}%` }}
              ></div>
            </div>
          </div>
          {mission.status === 'IN_PROGRESS' && (
            <p className="progress-note">Progress updates automatically every 5 seconds</p>
          )}
        </div>

        {/* Action Buttons */}
        <div className="action-buttons">
          {canPause && (
            <button
              onClick={handlePause}
              className="btn btn-pause"
              disabled={actionLoading !== null}
            >
              {actionLoading === 'pause' ? 'Pausing...' : '⏸ Pause Mission'}
            </button>
          )}
          {canResume && (
            <button
              onClick={handleResume}
              className="btn btn-resume"
              disabled={actionLoading !== null}
            >
              {actionLoading === 'resume' ? 'Resuming...' : '▶ Resume Mission'}
            </button>
          )}
          {canAbort && (
            <button
              onClick={handleAbort}
              className="btn btn-abort"
              disabled={actionLoading !== null}
            >
              {actionLoading === 'abort' ? 'Aborting...' : '⛔ Abort Mission'}
            </button>
          )}
          {!canPause && !canResume && !canAbort && (
            <p className="no-actions">No actions available for this mission status</p>
          )}
        </div>

        {/* Timeline Info */}
        <div className="timeline-card">
          <h3>Timeline</h3>
          <div className="timeline-items">
            <div className="timeline-item">
              <span className="timeline-label">Created:</span>
              <span className="timeline-value">{formatDate(mission.createdAt)}</span>
            </div>
            {mission.startedAt && (
              <div className="timeline-item">
                <span className="timeline-label">Started:</span>
                <span className="timeline-value">{formatDate(mission.startedAt)}</span>
              </div>
            )}
            {mission.pausedAt && (
              <div className="timeline-item">
                <span className="timeline-label">Paused:</span>
                <span className="timeline-value">{formatDate(mission.pausedAt)}</span>
              </div>
            )}
            {mission.abortedAt && (
              <div className="timeline-item">
                <span className="timeline-label">Aborted:</span>
                <span className="timeline-value">{formatDate(mission.abortedAt)}</span>
              </div>
            )}
            {mission.lastProgressUpdate && (
              <div className="timeline-item">
                <span className="timeline-label">Last Update:</span>
                <span className="timeline-value">{formatDate(mission.lastProgressUpdate)}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default MissionMonitor
