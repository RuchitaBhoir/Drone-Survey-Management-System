import { useEffect, useState } from 'react'
import { missionService } from '../services/missionService'
import MissionForm from '../components/MissionForm'
import MissionList from '../components/MissionList'
import './MissionPlanner.css'

/**
 * MissionPlanner Page
 * Main page for mission planning and management
 */
const MissionPlanner = () => {
  const [missions, setMissions] = useState([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchMissions()
  }, [])

  /**
   * Fetch all missions from the backend
   */
  const fetchMissions = async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await missionService.getAll()
      setMissions(response.data || [])
    } catch (err) {
      setError(err.message)
      console.error('Error fetching missions:', err)
    } finally {
      setLoading(false)
    }
  }

  /**
   * Handle mission creation
   */
  const handleCreateMission = async (formData) => {
    try {
      setSubmitting(true)
      setError(null)
      const response = await missionService.create(formData)
      
      // Add new mission to the list
      setMissions([response.data, ...missions])
      
      return response
    } catch (err) {
      setError(err.message)
      throw err
    } finally {
      setSubmitting(false)
    }
  }

  /**
   * Handle starting a mission (change status to IN_PROGRESS)
   */
  const handleStartMission = async (missionId) => {
    try {
      setError(null)
      // Update mission status to IN_PROGRESS
      const response = await missionService.updateStatus(missionId, {
        status: 'IN_PROGRESS'
      })
      
      // Update the mission in the list
      setMissions(missions.map(mission => 
        mission.id === missionId ? response.data : mission
      ))
    } catch (err) {
      setError(err.message)
      alert(`Error starting mission: ${err.message}`)
      console.error('Error starting mission:', err)
    }
  }

  return (
    <div className="mission-planner">
      <div className="page-header">
        <h1>Mission Planner</h1>
        <button 
          onClick={fetchMissions} 
          className="btn btn-secondary"
          disabled={loading}
        >
          {loading ? 'Refreshing...' : 'Refresh'}
        </button>
      </div>

      {error && missions.length === 0 && (
        <div className="error">
          <p>Error: {error}</p>
          <button onClick={fetchMissions} className="btn btn-primary">
            Retry
          </button>
        </div>
      )}

      <div className="mission-planner-content">
        <div className="mission-form-section">
          <MissionForm 
            onSubmit={handleCreateMission}
            loading={submitting}
          />
        </div>

        <div className="mission-list-section">
          <MissionList 
            missions={missions.map(mission => ({
              ...mission,
              onStart: handleStartMission
            }))}
            loading={loading}
          />
        </div>
      </div>
    </div>
  )
}

export default MissionPlanner
