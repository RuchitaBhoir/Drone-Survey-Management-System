import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { surveyAPI } from '../services/api'
import './Surveys.css'

const Surveys = () => {
  const [surveys, setSurveys] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchSurveys()
  }, [])

  const fetchSurveys = async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await surveyAPI.getAll()
      setSurveys(response.data || [])
    } catch (err) {
      setError(err.message)
      console.error('Error fetching surveys:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this survey?')) {
      return
    }

    try {
      await surveyAPI.delete(id)
      setSurveys(surveys.filter(s => s.id !== id))
    } catch (err) {
      alert('Error deleting survey: ' + err.message)
    }
  }

  const getStatusBadgeClass = (status) => {
    const classes = {
      pending: 'badge-pending',
      in_progress: 'badge-in-progress',
      completed: 'badge-completed',
      cancelled: 'badge-cancelled'
    }
    return classes[status] || 'badge-pending'
  }

  if (loading) {
    return <div className="loading">Loading surveys...</div>
  }

  if (error) {
    return <div className="error">Error: {error}</div>
  }

  return (
    <div className="surveys-page">
      <div className="page-header">
        <h1>All Surveys</h1>
        <Link to="/surveys/new" className="btn btn-primary">
          Create New Survey
        </Link>
      </div>

      {surveys.length === 0 ? (
        <div className="empty-state">
          <p>No surveys found. Create your first survey!</p>
          <Link to="/surveys/new" className="btn btn-primary">
            Create Survey
          </Link>
        </div>
      ) : (
        <div className="surveys-table">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Location</th>
                <th>Status</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {surveys.map(survey => (
                <tr key={survey.id}>
                  <td>
                    <Link to={`/surveys/${survey.id}`} className="survey-link">
                      {survey.name}
                    </Link>
                  </td>
                  <td>{survey.location}</td>
                  <td>
                    <span className={`badge ${getStatusBadgeClass(survey.status)}`}>
                      {survey.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td>{new Date(survey.createdAt).toLocaleDateString()}</td>
                  <td>
                    <div className="actions">
                      <Link to={`/surveys/${survey.id}`} className="btn btn-sm btn-secondary">
                        View
                      </Link>
                      <button
                        onClick={() => handleDelete(survey.id)}
                        className="btn btn-sm btn-danger"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

export default Surveys
