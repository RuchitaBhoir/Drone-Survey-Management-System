import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Surveys from './pages/Surveys'
import SurveyDetail from './pages/SurveyDetail'
import CreateSurvey from './pages/CreateSurvey'
import FleetDashboard from './pages/FleetDashboard'
import MissionPlanner from './pages/MissionPlanner'
import MissionMonitor from './pages/MissionMonitor'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/surveys" element={<Surveys />} />
        <Route path="/surveys/:id" element={<SurveyDetail />} />
        <Route path="/surveys/new" element={<CreateSurvey />} />
        <Route path="/fleet" element={<FleetDashboard />} />
        <Route path="/missions" element={<MissionPlanner />} />
        <Route path="/missions/:id/monitor" element={<MissionMonitor />} />
      </Routes>
    </Layout>
  )
}

export default App
