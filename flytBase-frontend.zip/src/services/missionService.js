import api from './api'

/**
 * Mission Service
 * Handles all mission-related API calls
 */
export const missionService = {
  /**
   * Get all missions
   */
  getAll: () => api.get('/missions'),

  /**
   * Get mission by ID
   */
  getById: (id) => api.get(`/missions/${id}`),

  /**
   * Create a new mission
   */
  create: (data) => api.post('/missions', data),

  /**
   * Update mission status and progress
   */
  updateStatus: (id, data) => api.put(`/missions/${id}/status`, data),

  /**
   * Monitor mission progress (with live updates)
   */
  monitor: (id) => api.get(`/missions/${id}/monitor`),

  /**
   * Control mission (pause, resume, or abort)
   * @param {number} id - Mission ID
   * @param {string} action - Action to perform: "pause", "resume", or "abort"
   */
  control: (id, action) => api.put(`/missions/${id}/control`, { action }),

  /**
   * Pause mission (uses control endpoint)
   */
  pause: (id) => api.put(`/missions/${id}/control`, { action: 'pause' }),

  /**
   * Resume mission (uses control endpoint)
   */
  resume: (id) => api.put(`/missions/${id}/control`, { action: 'resume' }),

  /**
   * Abort mission (uses control endpoint)
   */
  abort: (id) => api.put(`/missions/${id}/control`, { action: 'abort' })
}

export default missionService
