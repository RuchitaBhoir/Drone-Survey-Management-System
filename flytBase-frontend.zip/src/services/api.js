import axios from 'axios'

const API_BASE_URL = import.meta.env.API_BASE_URL || 'http://localhost:5001/api'

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Request interceptor
api.interceptors.request.use(
  (config) => {
    // Add auth token if available
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const message = error.response?.data?.message || error.message || 'An error occurred'
    return Promise.reject(new Error(message))
  }
)

// Survey API methods
export const surveyAPI = {
  // Get all surveys
  getAll: () => api.get('/surveys'),
  
  // Get survey by ID
  getById: (id) => api.get(`/surveys/${id}`),
  
  // Create survey
  create: (data) => api.post('/surveys', data),
  
  // Update survey
  update: (id, data) => api.put(`/surveys/${id}`, data),
  
  // Delete survey
  delete: (id) => api.delete(`/surveys/${id}`)
}

export default api
