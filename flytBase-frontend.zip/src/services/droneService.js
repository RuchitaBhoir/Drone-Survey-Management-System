import api from './api'

/**
 * Drone Service
 * Handles all drone-related API calls
 */
export const droneService = {
  /**
   * Get all drones
   */
  getAll: () => api.get('/drones'),

  /**
   * Get available drones (status = AVAILABLE)
   */
  getAvailable: () => api.get('/drones/available'),

  /**
   * Create a new drone
   */
  create: (data) => api.post('/drones', data),

  /**
   * Update drone status and battery
   */
  updateStatus: (id, data) => api.put(`/drones/${id}/status`, data)
}

export default droneService
