import { getDB } from '../config/database.js';
import { Mission } from '../models/Mission.js';

/**
 * Data Access Object for Mission Monitoring operations
 * Handles pause, resume, abort, and progress tracking
 */
export class MissionMonitoringDAO {
  /**
   * Get mission with calculated progress (for monitoring)
   */
  static async getMissionForMonitoring(id) {
    try {
      const db = getDB();
      const [rows] = await db.query(
        'SELECT * FROM missions WHERE id = ?',
        [id]
      );
      
      if (rows.length === 0) {
        return null;
      }

      const mission = new Mission(rows[0]);
      
      // Calculate progress based on time if mission is IN_PROGRESS
      if (mission.status === 'IN_PROGRESS' && mission.startedAt) {
        const startedAt = new Date(mission.startedAt);
        const now = new Date();
        const elapsedSeconds = (now - startedAt) / 1000;
        
        // Simulate progress: assume mission takes 300 seconds (5 minutes) to complete
        // Adjust this based on your needs
        const estimatedDuration = 300; // seconds
        const calculatedProgress = Math.min(100, Math.floor((elapsedSeconds / estimatedDuration) * 100));
        
        // Update progress if it has increased
        if (calculatedProgress > mission.progress) {
          await this.updateProgress(id, calculatedProgress);
          mission.progress = calculatedProgress;
        }
      }
      
      return mission;
    } catch (error) {
      console.error('Error in MissionMonitoringDAO.getMissionForMonitoring:', error);
      throw error;
    }
  }

  /**
   * Update mission progress
   */
  static async updateProgress(id, progress) {
    try {
      const db = getDB();
      
      if (progress < 0 || progress > 100) {
        throw new Error('Progress must be between 0 and 100');
      }

      // Auto-complete mission if progress reaches 100
      let statusUpdate = '';
      if (progress >= 100) {
        statusUpdate = ', status = "COMPLETED"';
      }

      await db.query(
        `UPDATE missions SET progress = ?, last_progress_update = NOW()${statusUpdate} WHERE id = ?`,
        [progress, id]
      );

      return await this.findById(id);
    } catch (error) {
      console.error('Error in MissionMonitoringDAO.updateProgress:', error);
      throw error;
    }
  }

  /**
   * Pause a mission
   */
  static async pauseMission(id) {
    try {
      const db = getDB();
      
      // Check if mission exists and is in progress
      const [rows] = await db.query(
        'SELECT * FROM missions WHERE id = ?',
        [id]
      );
      
      if (rows.length === 0) {
        return null;
      }

      // Convert to Mission model to get camelCase properties
      const missionModel = new Mission(rows[0]);
      
      if (missionModel.status !== 'IN_PROGRESS') {
        throw new Error(`Cannot pause mission. Current status: ${missionModel.status}. Only IN_PROGRESS missions can be paused.`);
      }

      await db.query(
        'UPDATE missions SET status = "PAUSED", paused_at = NOW() WHERE id = ?',
        [id]
      );

      return await this.findById(id);
    } catch (error) {
      console.error('Error in MissionMonitoringDAO.pauseMission:', error);
      throw error;
    }
  }

  /**
   * Resume a paused mission
   */
  static async resumeMission(id) {
    try {
      const db = getDB();
      
      // Check if mission exists and is paused
      const [rows] = await db.query(
        'SELECT * FROM missions WHERE id = ?',
        [id]
      );
      
      if (rows.length === 0) {
        return null;
      }

      // Convert to Mission model to get camelCase properties
      const missionModel = new Mission(rows[0]);
      
      if (missionModel.status !== 'PAUSED') {
        throw new Error(`Cannot resume mission. Current status: ${missionModel.status}. Only PAUSED missions can be resumed.`);
      }

      // Calculate paused duration and adjust started_at
      const pausedAt = missionModel.pausedAt ? new Date(missionModel.pausedAt) : new Date();
      const startedAt = missionModel.startedAt ? new Date(missionModel.startedAt) : new Date();
      const pausedDuration = (new Date() - pausedAt) / 1000; // seconds
      const originalElapsed = (pausedAt - startedAt) / 1000; // seconds before pause
      const totalElapsed = originalElapsed; // Total active time (excluding paused time)
      
      // Update started_at to account for paused time (move it forward by paused duration)
      await db.query(
        `UPDATE missions 
         SET status = "IN_PROGRESS", 
             started_at = DATE_SUB(NOW(), INTERVAL ? SECOND),
             paused_at = NULL,
             last_progress_update = NOW()
         WHERE id = ?`,
        [Math.floor(totalElapsed), id]
      );

      return await this.findById(id);
    } catch (error) {
      console.error('Error in MissionMonitoringDAO.resumeMission:', error);
      throw error;
    }
  }

  /**
   * Abort a mission
   */
  static async abortMission(id) {
    try {
      const db = getDB();
      
      // Check if mission exists
      const [rows] = await db.query(
        'SELECT * FROM missions WHERE id = ?',
        [id]
      );
      
      if (rows.length === 0) {
        return null;
      }

      // Convert to Mission model to get camelCase properties
      const missionModel = new Mission(rows[0]);
      
      if (missionModel.status === 'COMPLETED') {
        throw new Error('Cannot abort a completed mission');
      }

      if (missionModel.status === 'ABORTED') {
        throw new Error('Mission is already aborted');
      }

      await db.query(
        'UPDATE missions SET status = "ABORTED", aborted_at = NOW() WHERE id = ?',
        [id]
      );

      // Free the drone when mission is aborted
      if (missionModel.droneId) {
        await db.query('UPDATE drones SET status = "AVAILABLE" WHERE id = ?', [missionModel.droneId]);
      }

      return await this.findById(id);
    } catch (error) {
      console.error('Error in MissionMonitoringDAO.abortMission:', error);
      throw error;
    }
  }

  /**
   * Helper method to get mission by ID
   */
  static async findById(id) {
    try {
      const db = getDB();
      const [rows] = await db.query(
        'SELECT * FROM missions WHERE id = ?',
        [id]
      );
      return rows.length > 0 ? new Mission(rows[0]) : null;
    } catch (error) {
      console.error('Error in MissionMonitoringDAO.findById:', error);
      throw error;
    }
  }

  /**
   * Start a mission (set started_at when status changes to IN_PROGRESS)
   */
  static async startMission(id) {
    try {
      const db = getDB();
      await db.query(
        'UPDATE missions SET started_at = NOW(), last_progress_update = NOW() WHERE id = ?',
        [id]
      );
      return await this.findById(id);
    } catch (error) {
      console.error('Error in MissionMonitoringDAO.startMission:', error);
      throw error;
    }
  }
}
