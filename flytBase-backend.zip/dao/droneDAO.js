import { getDB } from '../config/database.js';
import { Drone } from '../models/Drone.js';

/**
 * Data Access Object for Drone operations
 */
export class DroneDAO {
  /**
   * Get all drones
   */
  static async findAll() {
    try {
      const db = getDB();
      const [rows] = await db.query(
        'SELECT * FROM drones ORDER BY created_at DESC'
      );
      return rows.map(row => new Drone(row));
    } catch (error) {
      console.error('Error in DroneDAO.findAll:', error);
      throw error;
    }
  }

  /**
   * Get all available drones (status = 'AVAILABLE')
   */
  static async findAvailable() {
    try {
      const db = getDB();
      const [rows] = await db.query(
        'SELECT * FROM drones WHERE status = "AVAILABLE" ORDER BY battery_level DESC, created_at DESC'
      );
      return rows.map(row => new Drone(row));
    } catch (error) {
      console.error('Error in DroneDAO.findAvailable:', error);
      throw error;
    }
  }

  /**
   * Get drone by ID
   */
  static async findById(id) {
    try {
      const db = getDB();
      const [rows] = await db.query(
        'SELECT * FROM drones WHERE id = ?',
        [id]
      );
      return rows.length > 0 ? new Drone(rows[0]) : null;
    } catch (error) {
      console.error('Error in DroneDAO.findById:', error);
      throw error;
    }
  }

  /**
   * Create a new drone
   * Accepts camelCase data, converts to snake_case for database
   */
  static async create(droneData) {
    try {
      const db = getDB();
      
      // Normalize: accept both camelCase and snake_case, convert to camelCase
      const normalized = {
        droneName: droneData.droneName || droneData.drone_name || '',
        status: droneData.status || 'AVAILABLE',
        batteryLevel: droneData.batteryLevel !== undefined ? droneData.batteryLevel : (droneData.battery_level !== undefined ? droneData.battery_level : 100),
        lastLocation: droneData.lastLocation || droneData.last_location || ''
      };
      
      const [result] = await db.query(
        `INSERT INTO drones (drone_name, status, battery_level, last_location)
         VALUES (?, ?, ?, ?)`,
        [
          normalized.droneName,
          normalized.status,
          normalized.batteryLevel,
          normalized.lastLocation
        ]
      );
      return await this.findById(result.insertId);
    } catch (error) {
      console.error('Error in DroneDAO.create:', error);
      throw error;
    }
  }

  /**
   * Update drone status, battery level, and last location
   */
  static async updateStatus(id, status, batteryLevel, lastLocation) {
    try {
      const db = getDB();
      
      // Validate status
      if (status && !['AVAILABLE', 'IN_MISSION'].includes(status)) {
        throw new Error('Invalid status. Must be AVAILABLE or IN_MISSION');
      }

      // Validate battery level
      if (batteryLevel !== undefined) {
        if (batteryLevel < 0 || batteryLevel > 100) {
          throw new Error('Battery level must be between 0 and 100');
        }
      }

      const updates = [];
      const values = [];

      if (status) {
        updates.push('status = ?');
        values.push(status);
      }

      if (batteryLevel !== undefined) {
        updates.push('battery_level = ?');
        values.push(batteryLevel);
      }

      if (lastLocation !== undefined) {
        updates.push('last_location = ?');
        values.push(lastLocation);
      }

      if (updates.length === 0) {
        return await this.findById(id);
      }

      values.push(id);

      await db.query(
        `UPDATE drones SET ${updates.join(', ')} WHERE id = ?`,
        values
      );

      return await this.findById(id);
    } catch (error) {
      console.error('Error in DroneDAO.updateStatus:', error);
      throw error;
    }
  }
}
