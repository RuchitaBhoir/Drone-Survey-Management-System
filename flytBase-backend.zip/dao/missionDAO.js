import { getDB } from '../config/database.js';
import { Mission } from '../models/Mission.js';

/**
 * Data Access Object for Mission operations
 */
export class MissionDAO {
  /**
   * Get all missions
   */
  static async findAll() {
    try {
      const db = getDB();
      const [rows] = await db.query(
        'SELECT * FROM missions ORDER BY created_at DESC'
      );
      return rows.map(row => new Mission(row));
    } catch (error) {
      console.error('Error in MissionDAO.findAll:', error);
      throw error;
    }
  }

  /**
   * Get mission by ID
   */
  static async findById(id) {
    try {
      const db = getDB();
      const [rows] = await db.query(
        'SELECT * FROM missions WHERE id = ?',
        [id]
      );
      return rows.length > 0 ? new Mission(rows[0]) : null;
    } catch (error) {
      console.error('Error in MissionDAO.findById:', error);
      throw error;
    }
  }

  /**
   * Create a new mission
   * Accepts camelCase data, converts to snake_case for database
   */
  static async create(missionData) {
    try {
      const db = getDB();
      
      // Normalize: accept both camelCase and snake_case, convert to camelCase
      const normalized = {
        missionName: missionData.missionName || missionData.mission_name || '',
        areaName: missionData.areaName || missionData.area_name || '',
        altitude: missionData.altitude !== undefined ? missionData.altitude : 100,
        patternType: missionData.patternType || missionData.pattern_type || 'PERIMETER',
        status: missionData.status || 'PLANNED',
        progress: missionData.progress !== undefined ? missionData.progress : 0,
        // Accept both centerLat/centerLng and latitude/longitude for backward compatibility
        centerLat: missionData.centerLat !== undefined ? missionData.centerLat : (missionData.latitude !== undefined ? missionData.latitude : null),
        centerLng: missionData.centerLng !== undefined ? missionData.centerLng : (missionData.longitude !== undefined ? missionData.longitude : null),
        droneId: missionData.droneId !== undefined ? missionData.droneId : (missionData.drone_id !== undefined ? missionData.drone_id : null)
      };
      
      const [result] = await db.query(
        `INSERT INTO missions (mission_name, area_name, altitude, pattern_type, status, progress, center_lat, center_lng, drone_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          normalized.missionName,
          normalized.areaName,
          normalized.altitude,
          normalized.patternType,
          normalized.status,
          normalized.progress,
          normalized.centerLat,
          normalized.centerLng,
          normalized.droneId
        ]
      );
      
      // If drone is assigned, update drone status to IN_MISSION
      if (normalized.droneId) {
        await db.query(
          'UPDATE drones SET status = "IN_MISSION" WHERE id = ?',
          [normalized.droneId]
        );
      }
      
      return await this.findById(result.insertId);
      return await this.findById(result.insertId);
    } catch (error) {
      console.error('Error in MissionDAO.create:', error);
      throw error;
    }
  }

  /**
   * Update mission status and progress
   */
  static async updateStatus(id, status, progress) {
    try {
      const db = getDB();
      
      // Validate status
      if (status && !['PLANNED', 'IN_PROGRESS', 'PAUSED', 'COMPLETED', 'ABORTED'].includes(status)) {
        throw new Error('Invalid status. Must be PLANNED, IN_PROGRESS, PAUSED, COMPLETED, or ABORTED');
      }

      // Validate progress
      if (progress !== undefined) {
        if (progress < 0 || progress > 100) {
          throw new Error('Progress must be between 0 and 100');
        }
      }

      // Check current mission state
      const [existing] = await db.query('SELECT status, started_at, drone_id FROM missions WHERE id = ?', [id]);
      const currentStatus = existing.length > 0 ? existing[0].status : null;
      const currentDroneId = existing.length > 0 ? existing[0].drone_id : null;

      const updates = [];
      const values = [];

      if (status) {
        updates.push('status = ?');
        values.push(status);
        
        // Set started_at when status changes to IN_PROGRESS (only if not already set)
        if (status === 'IN_PROGRESS' && currentStatus !== 'IN_PROGRESS') {
          updates.push('started_at = NOW()');
          updates.push('last_progress_update = NOW()');
        }
        
        // Set aborted_at when status changes to ABORTED
        if (status === 'ABORTED') {
          updates.push('aborted_at = NOW()');
          // Free the drone when mission is aborted
          if (currentDroneId) {
            await db.query('UPDATE drones SET status = "AVAILABLE" WHERE id = ?', [currentDroneId]);
          }
        }
        
        // Free the drone when mission is completed
        if (status === 'COMPLETED' && currentStatus !== 'COMPLETED' && currentDroneId) {
          await db.query('UPDATE drones SET status = "AVAILABLE" WHERE id = ?', [currentDroneId]);
        }
      }

      if (progress !== undefined) {
        updates.push('progress = ?');
        values.push(progress);
        updates.push('last_progress_update = NOW()');
        
        // Auto-complete if progress reaches 100
        if (progress >= 100 && currentStatus !== 'COMPLETED') {
          updates.push('status = "COMPLETED"');
          // Free the drone when mission auto-completes
          if (currentDroneId) {
            await db.query('UPDATE drones SET status = "AVAILABLE" WHERE id = ?', [currentDroneId]);
          }
        }
      }

      if (updates.length === 0) {
        return await this.findById(id);
      }

      values.push(id);

      await db.query(
        `UPDATE missions SET ${updates.join(', ')} WHERE id = ?`,
        values
      );

      return await this.findById(id);
    } catch (error) {
      console.error('Error in MissionDAO.updateStatus:', error);
      throw error;
    }
  }
}
