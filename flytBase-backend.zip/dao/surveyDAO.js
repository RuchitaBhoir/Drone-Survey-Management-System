import { getDB } from '../config/database.js';
import { Survey } from '../models/Survey.js';

/**
 * Data Access Object for Survey operations
 */
export class SurveyDAO {
  /**
   * Get all surveys
   */
  static async findAll() {
    try {
      const db = getDB();
      const [rows] = await db.query(
        'SELECT * FROM surveys ORDER BY createdAt DESC'
      );
      return rows.map(row => new Survey(row));
    } catch (error) {
      console.error('Error in SurveyDAO.findAll:', error);
      throw error;
    }
  }

  /**
   * Get survey by ID
   */
  static async findById(id) {
    try {
      const db = getDB();
      const [rows] = await db.query(
        'SELECT * FROM surveys WHERE id = ?',
        [id]
      );
      return rows.length > 0 ? new Survey(rows[0]) : null;
    } catch (error) {
      console.error('Error in SurveyDAO.findById:', error);
      throw error;
    }
  }

  /**
   * Create a new survey
   */
  static async create(surveyData) {
    try {
      const db = getDB();
      const [result] = await db.query(
        `INSERT INTO surveys (name, description, location, latitude, longitude, status, createdBy)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          surveyData.name,
          surveyData.description,
          surveyData.location,
          surveyData.latitude,
          surveyData.longitude,
          surveyData.status || 'pending',
          surveyData.createdBy
        ]
      );
      return await this.findById(result.insertId);
    } catch (error) {
      console.error('Error in SurveyDAO.create:', error);
      throw error;
    }
  }

  /**
   * Update a survey
   */
  static async update(id, surveyData) {
    try {
      const db = getDB();
      const fields = [];
      const values = [];

      Object.keys(surveyData).forEach(key => {
        if (surveyData[key] !== undefined && key !== 'id') {
          fields.push(`${key} = ?`);
          values.push(surveyData[key]);
        }
      });

      if (fields.length === 0) {
        return await this.findById(id);
      }

      fields.push('updatedAt = NOW()');
      values.push(id);

      await db.query(
        `UPDATE surveys SET ${fields.join(', ')} WHERE id = ?`,
        values
      );

      return await this.findById(id);
    } catch (error) {
      console.error('Error in SurveyDAO.update:', error);
      throw error;
    }
  }

  /**
   * Delete a survey
   */
  static async delete(id) {
    try {
      const db = getDB();
      const [result] = await db.query('DELETE FROM surveys WHERE id = ?', [id]);
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error in SurveyDAO.delete:', error);
      throw error;
    }
  }
}
