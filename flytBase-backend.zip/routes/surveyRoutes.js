import express from 'express';
import { SurveyController } from '../controllers/surveyController.js';

const router = express.Router();

// GET /api/surveys - Get all surveys
router.get('/', SurveyController.getAllSurveys);

// GET /api/surveys/:id - Get survey by ID
router.get('/:id', SurveyController.getSurveyById);

// POST /api/surveys - Create a new survey
router.post('/', SurveyController.createSurvey);

// PUT /api/surveys/:id - Update a survey
router.put('/:id', SurveyController.updateSurvey);

// DELETE /api/surveys/:id - Delete a survey
router.delete('/:id', SurveyController.deleteSurvey);

export default router;
