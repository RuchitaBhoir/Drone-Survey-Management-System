import express from 'express';
import { DroneController } from '../controllers/droneController.js';

const router = express.Router();

// GET /api/drones - Get all drones
router.get('/', DroneController.getAllDrones);

// GET /api/drones/available - Get available drones
router.get('/available', DroneController.getAvailableDrones);

// POST /api/drones - Add new drone
router.post('/', DroneController.createDrone);

// PUT /api/drones/:id/status - Update drone status & battery
router.put('/:id/status', DroneController.updateDroneStatus);

// GET /api/drones/:id - Get drone by ID
router.get('/:id', DroneController.getDroneById);

export default router;
