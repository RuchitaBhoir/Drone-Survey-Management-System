import express from 'express';
import { MissionController } from '../controllers/missionController.js';
import { MissionMonitoringController } from '../controllers/missionMonitoringController.js';

const router = express.Router();

// POST /api/missions - Create a new mission
router.post('/', MissionController.createMission);

// GET /api/missions - Get all missions
router.get('/', MissionController.getAllMissions);

// Monitoring routes (must come before /:id to avoid route conflicts)
// GET /api/missions/:id/monitor - Monitor mission progress
router.get('/:id/monitor', MissionMonitoringController.monitorMission);

// PUT /api/missions/:id/control - Control mission (pause, resume, or abort)
// Body: { "action": "pause" | "resume" | "abort" }
router.put('/:id/control', MissionMonitoringController.controlMission);

// Legacy routes (still supported for backward compatibility)
// PUT /api/missions/:id/pause - Pause mission
router.put('/:id/pause', MissionMonitoringController.pauseMission);

// PUT /api/missions/:id/resume - Resume mission
router.put('/:id/resume', MissionMonitoringController.resumeMission);

// PUT /api/missions/:id/abort - Abort mission
router.put('/:id/abort', MissionMonitoringController.abortMission);

// PUT /api/missions/:id/status - Update mission status & progress
router.put('/:id/status', MissionController.updateMissionStatus);

// GET /api/missions/:id - Get mission by ID (must be last)
router.get('/:id', MissionController.getMissionById);

export default router;
