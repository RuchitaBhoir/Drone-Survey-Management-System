import { MissionDAO } from '../dao/missionDAO.js';

/**
 * Mission Controller
 * Handles HTTP requests and responses for mission operations
 */
export class MissionController {
  /**
   * Get all missions
   * GET /api/missions
   */
  static async getAllMissions(req, res) {
    try {
      const missions = await MissionDAO.findAll();
      res.status(200).json({
        success: true,
        data: missions,
        count: missions.length
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching missions',
        error: error.message
      });
    }
  }

  /**
   * Get mission by ID
   * GET /api/missions/:id
   */
  static async getMissionById(req, res) {
    try {
      const { id } = req.params;
      const mission = await MissionDAO.findById(id);

      if (!mission) {
        return res.status(404).json({
          success: false,
          message: 'Mission not found'
        });
      }

      res.status(200).json({
        success: true,
        data: mission
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching mission',
        error: error.message
      });
    }
  }

  /**
   * Create a new mission
   * POST /api/missions
   */
  static async createMission(req, res) {
    try {
      const missionData = req.body;

      // Normalize: accept both camelCase and snake_case, prefer camelCase
      const normalizedData = {
        missionName: missionData.missionName || missionData.mission_name || '',
        areaName: missionData.areaName || missionData.area_name || '',
        altitude: missionData.altitude !== undefined ? missionData.altitude : 100,
        patternType: missionData.patternType || missionData.pattern_type || 'PERIMETER',
        status: missionData.status || 'PLANNED',
        progress: missionData.progress !== undefined ? missionData.progress : 0,
        // Accept both centerLat/centerLng and latitude/longitude for backward compatibility
        centerLat: missionData.centerLat,
        centerLng: missionData.centerLng,
        latitude: missionData.latitude,
        longitude: missionData.longitude,
        droneId: missionData.droneId !== undefined ? missionData.droneId : (missionData.drone_id !== undefined ? missionData.drone_id : null)
      };

      // Basic validation
      if (!normalizedData.missionName) {
        return res.status(400).json({
          success: false,
          message: 'Mission name is required'
        });
      }

      if (!normalizedData.areaName) {
        return res.status(400).json({
          success: false,
          message: 'Area name is required'
        });
      }

      // Validate patternType if provided
      if (normalizedData.patternType && !['PERIMETER', 'CROSSHATCH'].includes(normalizedData.patternType)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid pattern type. Must be PERIMETER or CROSSHATCH'
        });
      }

      // Validate status if provided
      if (normalizedData.status && !['PLANNED', 'IN_PROGRESS', 'PAUSED', 'COMPLETED', 'ABORTED'].includes(normalizedData.status)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid status. Must be PLANNED, IN_PROGRESS, PAUSED, COMPLETED, or ABORTED'
        });
      }

      // Validate altitude if provided
      if (normalizedData.altitude !== undefined) {
        if (normalizedData.altitude < 0) {
          return res.status(400).json({
            success: false,
            message: 'Altitude must be a positive number'
          });
        }
      }

      // Validate progress if provided
      if (normalizedData.progress !== undefined) {
        if (normalizedData.progress < 0 || normalizedData.progress > 100) {
          return res.status(400).json({
            success: false,
            message: 'Progress must be between 0 and 100'
          });
        }
      }

      const mission = await MissionDAO.create(normalizedData);
      res.status(201).json({
        success: true,
        message: 'Mission created successfully',
        data: mission
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error creating mission',
        error: error.message
      });
    }
  }

  /**
   * Update mission status and progress
   * PUT /api/missions/:id/status
   */
  static async updateMissionStatus(req, res) {
    try {
      const { id } = req.params;
      const { status, progress } = req.body;

      // Check if mission exists
      const existingMission = await MissionDAO.findById(id);
      if (!existingMission) {
        return res.status(404).json({
          success: false,
          message: 'Mission not found'
        });
      }

      // Validate that at least one field is provided
      if (status === undefined && progress === undefined) {
        return res.status(400).json({
          success: false,
          message: 'At least one of status or progress must be provided'
        });
      }

      const updatedMission = await MissionDAO.updateStatus(id, status, progress);
      res.status(200).json({
        success: true,
        message: 'Mission status updated successfully',
        data: updatedMission
      });
    } catch (error) {
      // Handle validation errors
      if (error.message.includes('Invalid status') || error.message.includes('Progress must be')) {
        return res.status(400).json({
          success: false,
          message: error.message
        });
      }

      res.status(500).json({
        success: false,
        message: 'Error updating mission status',
        error: error.message
      });
    }
  }
}
