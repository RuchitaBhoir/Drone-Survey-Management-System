import { DroneDAO } from '../dao/droneDAO.js';

/**
 * Drone Controller
 * Handles HTTP requests and responses for drone operations
 */
export class DroneController {
  /**
   * Get all drones
   * GET /api/drones
   */
  static async getAllDrones(req, res) {
    try {
      const drones = await DroneDAO.findAll();
      res.status(200).json({
        success: true,
        data: drones,
        count: drones.length
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching drones',
        error: error.message
      });
    }
  }

  /**
   * Get available drones (status = AVAILABLE)
   * GET /api/drones/available
   */
  static async getAvailableDrones(req, res) {
    try {
      const drones = await DroneDAO.findAvailable();
      res.status(200).json({
        success: true,
        data: drones,
        count: drones.length
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching available drones',
        error: error.message
      });
    }
  }

  /**
   * Create a new drone
   * POST /api/drones
   */
  static async createDrone(req, res) {
    try {
      const droneData = req.body;

      // Normalize: accept both camelCase and snake_case, prefer camelCase
      const normalizedData = {
        droneName: droneData.droneName || droneData.drone_name || '',
        status: droneData.status,
        batteryLevel: droneData.batteryLevel !== undefined ? droneData.batteryLevel : (droneData.battery_level !== undefined ? droneData.battery_level : 100),
        lastLocation: droneData.lastLocation || droneData.last_location || ''
      };

      // Basic validation
      if (!normalizedData.droneName) {
        return res.status(400).json({
          success: false,
          message: 'Drone name is required'
        });
      }

      // Validate status if provided
      if (normalizedData.status && !['AVAILABLE', 'IN_MISSION'].includes(normalizedData.status)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid status. Must be AVAILABLE or IN_MISSION'
        });
      }

      // Validate battery level if provided
      if (normalizedData.batteryLevel !== undefined) {
        if (normalizedData.batteryLevel < 0 || normalizedData.batteryLevel > 100) {
          return res.status(400).json({
            success: false,
            message: 'Battery level must be between 0 and 100'
          });
        }
      }

      const drone = await DroneDAO.create(normalizedData);
      res.status(201).json({
        success: true,
        message: 'Drone created successfully',
        data: drone
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error creating drone',
        error: error.message
      });
    }
  }

  /**
   * Update drone status, battery, and location
   * PUT /api/drones/:id/status
   */
  static async updateDroneStatus(req, res) {
    try {
      const { id } = req.params;
      const { 
        status, 
        battery_level, 
        batteryLevel,
        last_location,
        lastLocation
      } = req.body;

      // Normalize: accept both camelCase and snake_case, prefer camelCase
      const normalizedBatteryLevel = batteryLevel !== undefined ? batteryLevel : battery_level;
      const normalizedLastLocation = lastLocation !== undefined ? lastLocation : last_location;

      // Check if drone exists
      const existingDrone = await DroneDAO.findById(id);
      if (!existingDrone) {
        return res.status(404).json({
          success: false,
          message: 'Drone not found'
        });
      }

      // Validate that at least one field is provided
      if (status === undefined && normalizedBatteryLevel === undefined && normalizedLastLocation === undefined) {
        return res.status(400).json({
          success: false,
          message: 'At least one of status, batteryLevel, or lastLocation must be provided'
        });
      }

      const updatedDrone = await DroneDAO.updateStatus(
        id, 
        status, 
        normalizedBatteryLevel, 
        normalizedLastLocation
      );
      res.status(200).json({
        success: true,
        message: 'Drone Data updated successfully',
        data: updatedDrone
      });
    } catch (error) {
      // Handle validation errors
      if (error.message.includes('Invalid status') || error.message.includes('Battery level')) {
        return res.status(400).json({
          success: false,
          message: error.message
        });
      }

      res.status(500).json({
        success: false,
        message: 'Error updating drone data',
        error: error.message
      });
    }
  }

  /**
   * Get drone by ID
   * GET /api/drones/:id
   */
  static async getDroneById(req, res) {
    try {
      const { id } = req.params;
      const drone = await DroneDAO.findById(id);
      
      if (!drone) {
        return res.status(404).json({
          success: false,
          message: 'Drone not found'
        });
      }

      res.status(200).json({
        success: true,
        data: drone
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching drone',
        error: error.message
      });
    }
  }
}
