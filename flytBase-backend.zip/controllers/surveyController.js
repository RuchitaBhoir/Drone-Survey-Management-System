import { SurveyDAO } from '../dao/surveyDAO.js';

/**
 * Survey Controller
 * Handles HTTP requests and responses for survey operations
 */
export class SurveyController {
  /**
   * Get all surveys
   */
  static async getAllSurveys(req, res) {
    try {
      const surveys = await SurveyDAO.findAll();
      res.json({
        success: true,
        data: surveys,
        count: surveys.length
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching surveys',
        error: error.message
      });
    }
  }

  /**
   * Get survey by ID
   */
  static async getSurveyById(req, res) {
    try {
      const { id } = req.params;
      const survey = await SurveyDAO.findById(id);

      if (!survey) {
        return res.status(404).json({
          success: false,
          message: 'Survey not found'
        });
      }

      res.json({
        success: true,
        data: survey
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching survey',
        error: error.message
      });
    }
  }

  /**
   * Create a new survey
   */
  static async createSurvey(req, res) {
    console.log("reached here 1");
    
    try {
      const surveyData = req.body;

      // Basic validation
      if (!surveyData.name || !surveyData.location) {
        return res.status(400).json({
          success: false,
          message: 'Name and location are required'
        });
      }

      const survey = await SurveyDAO.create(surveyData);
      res.status(201).json({
        success: true,
        message: 'Survey created successfully',
        data: survey
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error creating survey',
        error: error.message
      });
    }
  }

  /**
   * Update a survey
   */
  static async updateSurvey(req, res) {
    try {
      const { id } = req.params;
      const surveyData = req.body;

      const existingSurvey = await SurveyDAO.findById(id);
      if (!existingSurvey) {
        return res.status(404).json({
          success: false,
          message: 'Survey not found'
        });
      }

      const updatedSurvey = await SurveyDAO.update(id, surveyData);
      res.json({
        success: true,
        message: 'Survey updated successfully',
        data: updatedSurvey
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error updating survey',
        error: error.message
      });
    }
  }

  /**
   * Delete a survey
   */
  static async deleteSurvey(req, res) {
    try {
      const { id } = req.params;
      const deleted = await SurveyDAO.delete(id);

      if (!deleted) {
        return res.status(404).json({
          success: false,
          message: 'Survey not found'
        });
      }

      res.json({
        success: true,
        message: 'Survey deleted successfully'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error deleting survey',
        error: error.message
      });
    }
  }
}
