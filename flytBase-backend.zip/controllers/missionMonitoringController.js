import { MissionMonitoringDAO } from '../dao/missionMonitoringDAO.js';
import { MissionDAO } from '../dao/missionDAO.js';

/**
 * Mission Monitoring Controller
 * Handles HTTP requests for mission monitoring operations
 */
export class MissionMonitoringController {
  /**
   * Get live mission progress
   * GET /api/missions/:id/monitor
   */
  static async monitorMission(req, res) {
    try {
      const { id } = req.params;
      const mission = await MissionMonitoringDAO.getMissionForMonitoring(id);

      if (!mission) {
        return res.status(404).json({
          success: false,
          message: 'Mission not found'
        });
      }

      // Calculate estimated time remaining (if in progress)
      let estimatedTimeRemaining = null;
      if (mission.status === 'IN_PROGRESS' && mission.progress > 0) {
        // Estimate: if 50% done, assume same time for remaining 50%
        const remainingProgress = 100 - mission.progress;
        const progressRate = mission.progress / 100; // percentage per estimated duration
        // Assuming 5 minutes total duration
        const estimatedTotalSeconds = 300;
        const elapsedSeconds = (mission.progress / 100) * estimatedTotalSeconds;
        const remainingSeconds = estimatedTotalSeconds - elapsedSeconds;
        estimatedTimeRemaining = Math.max(0, Math.ceil(remainingSeconds));
      }

      res.status(200).json({
        success: true,
        data: {
          ...mission.toJSON(),
          estimatedTimeRemainingSeconds: estimatedTimeRemaining
        },
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error monitoring mission',
        error: error.message
      });
    }
  }

  /**
   * Control mission (pause, resume, or abort)
   * PUT /api/missions/:id/control
   * Body: { "action": "pause" | "resume" | "abort" }
   */
  static async controlMission(req, res) {
    try {
      const { id } = req.params;
      const { action } = req.body;

      // Validate action
      if (!action) {
        return res.status(400).json({
          success: false,
          message: 'Action is required. Must be "pause", "resume", or "abort"'
        });
      }

      if (!['pause', 'resume', 'abort'].includes(action.toLowerCase())) {
        return res.status(400).json({
          success: false,
          message: 'Invalid action. Must be "pause", "resume", or "abort"'
        });
      }

      const actionLower = action.toLowerCase();
      let mission;
      let message;

      // Execute the appropriate action
      switch (actionLower) {
        case 'pause':
          mission = await MissionMonitoringDAO.pauseMission(id);
          message = 'Mission paused successfully';
          break;
        case 'resume':
          mission = await MissionMonitoringDAO.resumeMission(id);
          message = 'Mission resumed successfully';
          break;
        case 'abort':
          mission = await MissionMonitoringDAO.abortMission(id);
          message = 'Mission aborted successfully';
          break;
      }

      if (!mission) {
        return res.status(404).json({
          success: false,
          message: 'Mission not found'
        });
      }

      res.status(200).json({
        success: true,
        message: message,
        data: mission
      });
    } catch (error) {
      // Handle business logic errors
      if (
        error.message.includes('Cannot pause mission') ||
        error.message.includes('Cannot resume mission') ||
        error.message.includes('Cannot abort') ||
        error.message.includes('already aborted')
      ) {
        return res.status(400).json({
          success: false,
          message: error.message
        });
      }

      res.status(500).json({
        success: false,
        message: 'Error controlling mission',
        error: error.message
      });
    }
  }

  /**
   * Pause a mission (deprecated - use controlMission with action: "pause")
   * PUT /api/missions/:id/pause
   */
  static async pauseMission(req, res) {
    req.body = { action: 'pause' };
    return MissionMonitoringController.controlMission(req, res);
  }

  /**
   * Resume a paused mission (deprecated - use controlMission with action: "resume")
   * PUT /api/missions/:id/resume
   */
  static async resumeMission(req, res) {
    req.body = { action: 'resume' };
    return MissionMonitoringController.controlMission(req, res);
  }

  /**
   * Abort a mission (deprecated - use controlMission with action: "abort")
   * PUT /api/missions/:id/abort
   */
  static async abortMission(req, res) {
    req.body = { action: 'abort' };
    return MissionMonitoringController.controlMission(req, res);
  }
}
