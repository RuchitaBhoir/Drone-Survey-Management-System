/**
 * Case Converter Utility
 * Converts between camelCase (JavaScript/API) and snake_case (Database)
 */

/**
 * Convert snake_case to camelCase
 */
export function snakeToCamel(str) {
  return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
}

/**
 * Convert camelCase to snake_case
 */
export function camelToSnake(str) {
  return str.replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);
}

/**
 * Convert object keys from snake_case to camelCase
 */
export function objectSnakeToCamel(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(item => objectSnakeToCamel(item));
  
  const converted = {};
  for (const [key, value] of Object.entries(obj)) {
    const camelKey = snakeToCamel(key);
    converted[camelKey] = value && typeof value === 'object' && !(value instanceof Date)
      ? objectSnakeToCamel(value)
      : value;
  }
  return converted;
}

/**
 * Convert object keys from camelCase to snake_case
 */
export function objectCamelToSnake(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(item => objectCamelToSnake(item));
  
  const converted = {};
  for (const [key, value] of Object.entries(obj)) {
    const snakeKey = camelToSnake(key);
    converted[snakeKey] = value && typeof value === 'object' && !(value instanceof Date)
      ? objectCamelToSnake(value)
      : value;
  }
  return converted;
}
