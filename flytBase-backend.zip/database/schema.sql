-- Drone Survey Management System Database Schema

CREATE DATABASE IF NOT EXISTS drone_survey_db;
USE drone_survey_db;

-- Surveys Table
CREATE TABLE IF NOT EXISTS surveys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    status ENUM('pending', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending',
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    createdBy INT,
    INDEX idx_status (status),
    INDEX idx_createdAt (createdAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Drones Table
CREATE TABLE IF NOT EXISTS drones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    drone_name VARCHAR(255) NOT NULL,
    status ENUM('AVAILABLE', 'IN_MISSION') DEFAULT 'AVAILABLE',
    battery_level INT DEFAULT 100 CHECK (battery_level >= 0 AND battery_level <= 100),
    last_location VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_battery_level (battery_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data (optional)
INSERT INTO surveys (name, description, location, latitude, longitude, status) VALUES
('Agricultural Field Survey', 'Survey of 50-acre corn field for crop health analysis', 'Farm Road 123, County A', 40.7128, -74.0060, 'pending'),
('Construction Site Mapping', '3D mapping of construction site for progress tracking', 'Downtown District', 40.7589, -73.9851, 'in_progress'),
('Wildlife Habitat Assessment', 'Aerial survey of forest area for wildlife monitoring', 'National Park Reserve', 40.7489, -73.9680, 'completed');

-- Missions Table
CREATE TABLE IF NOT EXISTS missions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mission_name VARCHAR(255) NOT NULL,
    area_name VARCHAR(255) NOT NULL,
    altitude INT DEFAULT 100,
    pattern_type ENUM('PERIMETER', 'CROSSHATCH') DEFAULT 'PERIMETER',
    status ENUM('PLANNED', 'IN_PROGRESS', 'PAUSED', 'COMPLETED', 'ABORTED') DEFAULT 'PLANNED',
    progress INT DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    center_lat DECIMAL(10, 8) NULL,
    center_lng DECIMAL(11, 8) NULL,
    drone_id INT NULL,
    started_at TIMESTAMP NULL,
    paused_at TIMESTAMP NULL,
    aborted_at TIMESTAMP NULL,
    last_progress_update TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_pattern_type (pattern_type),
    INDEX idx_started_at (started_at),
    INDEX idx_center_location (center_lat, center_lng),
    INDEX idx_drone_id (drone_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample drone data (optional)
INSERT INTO drones (drone_name, status, battery_level, last_location) VALUES
('DJI Phantom 4 Pro', 'AVAILABLE', 95, 'Hangar A, Bay 1'),
('DJI Mavic 3', 'IN_MISSION', 78, 'Field Site Alpha'),
('Autel EVO II', 'AVAILABLE', 100, 'Hangar B, Bay 3');

-- Sample mission data (optional)
INSERT INTO missions (mission_name, area_name, altitude, pattern_type, status, progress) VALUES
('Agricultural Survey Mission', 'North Field Area', 120, 'CROSSHATCH', 'PLANNED', 0),
('Perimeter Mapping', 'Construction Site B', 80, 'PERIMETER', 'IN_PROGRESS', 45),
('Forest Coverage Scan', 'National Park Zone 3', 150, 'CROSSHATCH', 'COMPLETED', 100);
