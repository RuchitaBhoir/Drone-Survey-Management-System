-- Migration script: Add center_lat and center_lng columns to missions table
-- Run this query in MySQL Workbench or MySQL command line
-- Note: This replaces the previous latitude/longitude columns with center_lat/center_lng

USE drone_survey_db;

-- Option 1: If latitude/longitude columns exist, migrate data and rename
-- Step 1: Add new columns
ALTER TABLE missions 
ADD COLUMN IF NOT EXISTS center_lat DECIMAL(10, 8) NULL AFTER progress,
ADD COLUMN IF NOT EXISTS center_lng DECIMAL(11, 8) NULL AFTER center_lat;

-- Step 2: Migrate existing data from latitude/longitude to center_lat/center_lng (if columns exist)
-- UPDATE missions SET center_lat = latitude, center_lng = longitude WHERE latitude IS NOT NULL AND longitude IS NOT NULL;

-- Step 3: Drop old columns (uncomment if you want to remove latitude/longitude)
-- ALTER TABLE missions DROP COLUMN IF EXISTS latitude;
-- ALTER TABLE missions DROP COLUMN IF EXISTS longitude;

-- Option 2: If starting fresh, just add the columns
-- ALTER TABLE missions 
-- ADD COLUMN IF NOT EXISTS center_lat DECIMAL(10, 8) NULL AFTER progress,
-- ADD COLUMN IF NOT EXISTS center_lng DECIMAL(11, 8) NULL AFTER center_lat;

-- Add index for location-based queries (optional)
CREATE INDEX IF NOT EXISTS idx_center_location ON missions (center_lat, center_lng);
