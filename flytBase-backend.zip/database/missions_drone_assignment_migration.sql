-- Migration script: Add drone_id column to missions table
-- Run this query in MySQL Workbench or MySQL command line

USE drone_survey_db;

-- Add drone_id column with foreign key constraint
ALTER TABLE missions 
ADD COLUMN IF NOT EXISTS drone_id INT NULL AFTER center_lng,
ADD INDEX IF NOT EXISTS idx_drone_id (drone_id);

-- Add foreign key constraint (optional, for referential integrity)
-- ALTER TABLE missions 
-- ADD CONSTRAINT fk_mission_drone 
-- FOREIGN KEY (drone_id) REFERENCES drones(id) 
-- ON DELETE SET NULL;
