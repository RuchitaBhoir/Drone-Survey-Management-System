-- Migration script to add monitoring features to existing missions table
-- Run this if you already have a missions table

USE drone_survey_db;

-- Add new columns for monitoring
ALTER TABLE missions 
ADD COLUMN IF NOT EXISTS started_at TIMESTAMP NULL AFTER progress,
ADD COLUMN IF NOT EXISTS paused_at TIMESTAMP NULL AFTER started_at,
ADD COLUMN IF NOT EXISTS aborted_at TIMESTAMP NULL AFTER paused_at,
ADD COLUMN IF NOT EXISTS last_progress_update TIMESTAMP NULL AFTER aborted_at;

-- Update status ENUM to include PAUSED
-- Note: MySQL doesn't support IF NOT EXISTS for MODIFY COLUMN
-- If you get an error, the column may already be updated
ALTER TABLE missions 
MODIFY COLUMN status ENUM('PLANNED', 'IN_PROGRESS', 'PAUSED', 'COMPLETED', 'ABORTED') DEFAULT 'PLANNED';

-- Add index for started_at if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_started_at ON missions(started_at);
