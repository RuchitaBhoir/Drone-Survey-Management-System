-- Drones Table Creation Query
-- Run this query in MySQL Workbench or MySQL command line

USE drone_survey_db;

CREATE TABLE IF NOT EXISTS drones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    drone_name VARCHAR(255) NOT NULL,
    status ENUM('AVAILABLE', 'IN_MISSION') DEFAULT 'AVAILABLE',
    battery_level INT DEFAULT 100 CHECK (battery_level >= 0 AND battery_level <= 100),
    last_location VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_battery_level (battery_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data (optional)
INSERT INTO drones (drone_name, status, battery_level, last_location) VALUES
('DJI Phantom 4 Pro', 'AVAILABLE', 95, 'Hangar A, Bay 1'),
('DJI Mavic 3', 'IN_MISSION', 78, 'Field Site Alpha'),
('Autel EVO II', 'AVAILABLE', 100, 'Hangar B, Bay 3');
