-- ALTER TABLE command to add drone_id column to missions table
-- Run this query in MySQL Workbench or MySQL command line

USE drone_survey_db;

-- Add drone_id column after center_lng
ALTER TABLE missions 
ADD COLUMN drone_id INT NULL AFTER center_lng;

-- Add index on drone_id for better query performance
ALTER TABLE missions 
ADD INDEX idx_drone_id (drone_id);

-- Optional: Add foreign key constraint for referential integrity
-- Uncomment the following if you want to enforce foreign key relationship
-- ALTER TABLE missions 
-- ADD CONSTRAINT fk_mission_drone 
-- FOREIGN KEY (drone_id) REFERENCES drones(id) 
-- ON DELETE SET NULL;

-- Verify the column was added
-- SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT 
-- FROM INFORMATION_SCHEMA.COLUMNS 
-- WHERE TABLE_SCHEMA = 'drone_survey_db' 
-- AND TABLE_NAME = 'missions' 
-- AND COLUMN_NAME = 'drone_id';
