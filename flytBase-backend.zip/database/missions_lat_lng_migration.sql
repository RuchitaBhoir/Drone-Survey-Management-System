-- Migration script: Add latitude and longitude columns to missions table
-- Run this query in MySQL Workbench or MySQL command line

USE drone_survey_db;

-- Add latitude and longitude columns
ALTER TABLE missions 
ADD COLUMN IF NOT EXISTS latitude DECIMAL(10, 8) NULL AFTER progress,
ADD COLUMN IF NOT EXISTS longitude DECIMAL(11, 8) NULL AFTER latitude;

-- Add index for location-based queries (optional)
CREATE INDEX IF NOT EXISTS idx_location ON missions (latitude, longitude);
