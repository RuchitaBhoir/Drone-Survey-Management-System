-- Missions Table Creation Query
-- Run this query in MySQL Workbench or MySQL command line

USE drone_survey_db;

-- Drop existing table if you need to recreate with new schema
-- DROP TABLE IF EXISTS missions;

CREATE TABLE IF NOT EXISTS missions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mission_name VARCHAR(255) NOT NULL,
    area_name VARCHAR(255) NOT NULL,
    altitude INT DEFAULT 100,
    pattern_type ENUM('PERIMETER', 'CROSSHATCH') DEFAULT 'PERIMETER',
    status ENUM('PLANNED', 'IN_PROGRESS', 'PAUSED', 'COMPLETED', 'ABORTED') DEFAULT 'PLANNED',
    progress INT DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    center_lat DECIMAL(10, 8) NULL,
    center_lng DECIMAL(11, 8) NULL,
    started_at TIMESTAMP NULL,
    paused_at TIMESTAMP NULL,
    aborted_at TIMESTAMP NULL,
    last_progress_update TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_pattern_type (pattern_type),
    INDEX idx_started_at (started_at),
    INDEX idx_center_location (center_lat, center_lng)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Migration script: Add new columns to existing table (if table already exists)
-- ALTER TABLE missions 
-- ADD COLUMN IF NOT EXISTS started_at TIMESTAMP NULL AFTER progress,
-- ADD COLUMN IF NOT EXISTS paused_at TIMESTAMP NULL AFTER started_at,
-- ADD COLUMN IF NOT EXISTS aborted_at TIMESTAMP NULL AFTER paused_at,
-- ADD COLUMN IF NOT EXISTS last_progress_update TIMESTAMP NULL AFTER aborted_at,
-- ADD COLUMN IF NOT EXISTS center_lat DECIMAL(10, 8) NULL AFTER progress,
-- ADD COLUMN IF NOT EXISTS center_lng DECIMAL(11, 8) NULL AFTER center_lat,
-- MODIFY COLUMN status ENUM('PLANNED', 'IN_PROGRESS', 'PAUSED', 'COMPLETED', 'ABORTED') DEFAULT 'PLANNED';

-- Sample data (optional)
INSERT INTO missions (mission_name, area_name, altitude, pattern_type, status, progress) VALUES
('Agricultural Survey Mission', 'North Field Area', 120, 'CROSSHATCH', 'PLANNED', 0),
('Perimeter Mapping', 'Construction Site B', 80, 'PERIMETER', 'IN_PROGRESS', 45),
('Forest Coverage Scan', 'National Park Zone 3', 150, 'CROSSHATCH', 'COMPLETED', 100);
