import { objectSnakeToCamel } from '../utils/caseConverter.js';

/**
 * Mission Model
 * Represents a drone mission plan
 * Uses camelCase internally, converts from/to database snake_case
 */
export class Mission {
  constructor(data) {
    // Convert database snake_case to camelCase
    const camelData = objectSnakeToCamel(data);
    
    this.id = camelData.id || null;
    this.missionName = camelData.missionName || '';
    this.areaName = camelData.areaName || '';
    this.altitude = camelData.altitude !== undefined ? camelData.altitude : 100;
    this.patternType = camelData.patternType || 'PERIMETER'; // PERIMETER, CROSSHATCH
    this.status = camelData.status || 'PLANNED'; // PLANNED, IN_PROGRESS, PAUSED, COMPLETED, ABORTED
    this.progress = camelData.progress !== undefined ? camelData.progress : 0;
    this.centerLat = camelData.centerLat !== undefined ? camelData.centerLat : (camelData.latitude !== undefined ? camelData.latitude : null);
    this.centerLng = camelData.centerLng !== undefined ? camelData.centerLng : (camelData.longitude !== undefined ? camelData.longitude : null);
    this.droneId = camelData.droneId !== undefined ? camelData.droneId : (camelData.drone_id !== undefined ? camelData.drone_id : null);
    this.startedAt = camelData.startedAt || null;
    this.pausedAt = camelData.pausedAt || null;
    this.abortedAt = camelData.abortedAt || null;
    this.lastProgressUpdate = camelData.lastProgressUpdate || null;
    this.createdAt = camelData.createdAt || new Date();
  }

  /**
   * Convert to database format (snake_case)
   */
  toDatabaseFormat() {
    return {
      mission_name: this.missionName,
      area_name: this.areaName,
      altitude: this.altitude,
      pattern_type: this.patternType,
      status: this.status,
      progress: this.progress,
      center_lat: this.centerLat,
      center_lng: this.centerLng,
      drone_id: this.droneId
    };
  }

  /**
   * Convert to JSON (camelCase for API)
   */
  toJSON() {
    return {
      id: this.id,
      missionName: this.missionName,
      areaName: this.areaName,
      altitude: this.altitude,
      patternType: this.patternType,
      status: this.status,
      progress: this.progress,
      centerLat: this.centerLat,
      centerLng: this.centerLng,
      droneId: this.droneId,
      startedAt: this.startedAt,
      pausedAt: this.pausedAt,
      abortedAt: this.abortedAt,
      lastProgressUpdate: this.lastProgressUpdate,
      createdAt: this.createdAt
    };
  }
}
