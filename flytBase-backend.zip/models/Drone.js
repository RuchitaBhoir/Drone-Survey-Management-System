import { objectSnakeToCamel } from '../utils/caseConverter.js';

/**
 * Drone Model
 * Represents a drone in the fleet
 * Uses camelCase internally, converts from/to database snake_case
 */
export class Drone {
  constructor(data) {
    // Convert database snake_case to camelCase
    const camelData = objectSnakeToCamel(data);
    
    this.id = camelData.id || null;
    this.droneName = camelData.droneName || '';
    this.status = camelData.status || 'AVAILABLE'; // AVAILABLE, IN_MISSION
    this.batteryLevel = camelData.batteryLevel !== undefined ? camelData.batteryLevel : 100;
    this.lastLocation = camelData.lastLocation || '';
    this.createdAt = camelData.createdAt || new Date();
  }

  /**
   * Convert to database format (snake_case)
   */
  toDatabaseFormat() {
    return {
      drone_name: this.droneName,
      status: this.status,
      battery_level: this.batteryLevel,
      last_location: this.lastLocation
    };
  }

  /**
   * Convert to JSON (camelCase for API)
   */
  toJSON() {
    return {
      id: this.id,
      droneName: this.droneName,
      status: this.status,
      batteryLevel: this.batteryLevel,
      lastLocation: this.lastLocation,
      createdAt: this.createdAt
    };
  }
}
