/**
 * Survey Model
 * Represents a drone survey mission
 */
export class Survey {
  constructor(data) {
    this.id = data.id || null;
    this.name = data.name || '';
    this.description = data.description || '';
    this.location = data.location || '';
    this.latitude = data.latitude || null;
    this.longitude = data.longitude || null;
    this.status = data.status || 'pending'; // pending, in_progress, completed, cancelled
    this.createdAt = data.createdAt || new Date();
    this.updatedAt = data.updatedAt || new Date();
    this.createdBy = data.createdBy || null;
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      description: this.description,
      location: this.location,
      latitude: this.latitude,
      longitude: this.longitude,
      status: this.status,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
      createdBy: this.createdBy
    };
  }
}
